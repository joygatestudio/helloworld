// Required Libraries
const fs = require('fs');
const ethers = require('ethers');
require('dotenv').config();

// Load Configuration
const config = JSON.parse(fs.readFileSync('config.json', 'utf8'));
const { targetAddress, wbnbAddress, bnbAmount } = config;

// Connect to Ethereum Network
const provider = new ethers.providers.WebSocketProvider(process.env.WSSNODE);

// Pre-computed Values
const pancakeswapRouterAbi = JSON.parse(fs.readFileSync('abi.json', 'utf8'));
const pancakeswapRouterAddress = '0x10ED43C718714eb63d5aA57B78B54704E256024E';
const lowercaseTargetAddress = targetAddress.toLowerCase();

// Utility Functions
const formatTimestamp = () => {
  const date = new Date();
  const min = date.getMinutes().toString().padStart(2, '0');
  const sec = date.getSeconds().toString().padStart(2, '0');
  const ms = date.getMilliseconds().toString().padStart(3, '0');
  return `${min}:${sec}.${ms}`;
};

// Global Variables
let foundMatchingTransaction = false;
let currentNonce = null;
let matchingTransactionHash = null;

// Event Handlers
const handlePendingTransaction = async (txhash) => {
  try {
    const transaction = await provider.getTransaction(txhash);
    const pcsrouter = pancakeswapRouterAddress;
    const regex = /^(0xf305d719|0xc9567bf9|0xcb9a57d2)/i; //|0xc9567bf9

    if (transaction && transaction.to?.toLowerCase() === pcsrouter.toLowerCase() && regex.test(transaction.data) && transaction.data.includes(lowercaseTargetAddress.replace(/^0x/, ''))) {
      foundMatchingTransaction = true;
      matchingTransactionHash = transaction.hash;
      console.log(`${formatTimestamp()} - Matching Transaction Found: ${transaction.hash} \n Confirmation: ${transaction.confirmations}`);
      provider.off('pending', handlePendingTransaction);
    }
  } catch (error) {
    console.error('Error processing transaction:', error);
  }
};

// Trading Functions
const buyToken = async (txhash) => {
  const wallet = new ethers.Wallet(process.env.PRIVATE_KEY, provider);
  const pancakeswapRouter = new ethers.Contract(pancakeswapRouterAddress, pancakeswapRouterAbi, wallet);
  const deadline = Math.floor(Date.now() / 1000) + 60 * 20;
  const maxSimultaneousBuys = 1; // Defined maxSimultaneousBuys here

  try {
    const pendingTransaction = await provider.getTransaction(txhash);
    const pendingGasPrice = ethers.utils.formatUnits(pendingTransaction.gasPrice, 'gwei');

    if (currentNonce === null) {
      currentNonce = await provider.getTransactionCount(wallet.address, 'pending');
    }

    const startTime = new Date();
    const transactions = [];

    for (let i = 0; i < maxSimultaneousBuys; i++) {
      const tx = pancakeswapRouter.swapExactETHForTokens(0, [wbnbAddress, lowercaseTargetAddress], process.env.YOUR_WALLET_ADDRESS, deadline, {
        value: ethers.utils.parseUnits(bnbAmount.toString(), 'ether'),
        gasPrice: ethers.utils.parseUnits(pendingGasPrice, 'gwei'),
        gasLimit: ethers.utils.parseUnits('350000', 'wei'),
        nonce: currentNonce,
      });
      transactions.push(tx);
      currentNonce += 1;
    }

    const txHashes = await Promise.all(
      transactions.map(async (tx) => {
        const txResponse = await wallet.sendTransaction(tx);
        return txResponse.hash;
      })
    );

    const endTime = new Date();
    const executionTime = endTime - startTime;

    console.log(`${formatTimestamp()} - Matching Transaction to Transaction submitted time: ${executionTime}ms (max 10ms tolerance)`);
    console.log(`${formatTimestamp()} - Matching Transaction Submitted: ${txhash}`);

    await monitorForTransactionConfirmations(txHashes);
  } catch (error) {
    if (error.code !== 'REPLACEMENT_UNDERPRICED') {
      console.error('Error in buyToken:', error);
    }
  }
};

// Function to monitor transaction confirmations asynchronously
const monitorForTransactionConfirmations = async (txHashes) => {
  try {
    const receiptPromises = txHashes.map(async (txHash) => {
      const receipt = await provider.waitForTransaction(txHash);
      console.log(`${formatTimestamp()} - Transaction confirmed: ${receipt.transactionHash}`);
      return receipt;
    });

    const receipts = await Promise.all(receiptPromises);
  } catch (error) {
    console.error('Error waiting for transaction confirmations:', error);
  }
};

// High-Frequency Scanning Loop
const scan = () => {
  if (foundMatchingTransaction) {
    buyToken(matchingTransactionHash);
    foundMatchingTransaction = false;
  } else {
    setImmediate(scan);
  }
};

// Main Execution Function
const main = async () => {
  provider.on('pending', handlePendingTransaction);
  scan();
};

// Start the Script
main();
