// Required Libraries
const fs = require('fs');
const ethers = require('ethers');
require('dotenv').config();

// Load Configuration
const config = JSON.parse(fs.readFileSync('config.json', 'utf8'));
const { targetAddress, wbnbAddress, bnbAmount } = config;

// Connect to Ethereum Network
const provider = new ethers.providers.WebSocketProvider(process.env.WSSNODE);

// Pre-computed Values
const pancakeswapRouterAbi = JSON.parse(fs.readFileSync('abiV22.json', 'utf8'));
const pancakeswapRouterAddress = '0x10ED43C718714eb63d5aA57B78B54704E256024E';
const customRouterAddress = '0xCeFeB1B9E773aAC72bEe9335B57616544Fa3e425';
const lowercaseTargetAddress = targetAddress.toLowerCase();
// Utility Functions
const formatTimestamp = () => {
  const date = new Date();
  const min = date.getMinutes().toString().padStart(2, '0');
  const sec = date.getSeconds().toString().padStart(2, '0');
  const ms = date.getMilliseconds().toString().padStart(3, '0');
  return `${min}:${sec}.${ms}`;
};

// Global Variables
let foundMatchingTransaction = false;
let currentNonce = null;
let matchingTransactionHash = null;

// Event Handlers
const handlePendingTransaction = async (txhash) => {
  try {
    const transaction = await provider.getTransaction(txhash);
    const pcsrouter = pancakeswapRouterAddress;
    const regex = /^(0xf305d719|0xcb9a57d2|0xc9567bf9)/i;

    if (transaction && transaction.to?.toLowerCase() === pcsrouter.toLowerCase() && regex.test(transaction.data) && transaction.data.includes(lowercaseTargetAddress.replace(/^0x/, ''))) {
      foundMatchingTransaction = true;
      matchingTransactionHash = transaction.hash;
      console.log(`${formatTimestamp()} - Matching Transaction Found: ${transaction.hash} \n Confirmation: ${transaction.confirmations}`);
      provider.off('pending', handlePendingTransaction);
    }
  } catch (error) {
    console.error('Error processing transaction:', error);
  }
};

// Trading Functions
const buyToken = async (txhash) => {
  const wallet = new ethers.Wallet(process.env.PRIVATE_KEY, provider);
  const pancakeswapRouter = new ethers.Contract(customRouterAddress, pancakeswapRouterAbi, wallet);
  const deadline = Math.floor(Date.now() / 1000) + 60 * 20;

  try {
    const pendingTransaction = await provider.getTransaction(txhash);
    const pendingGasPrice = ethers.utils.formatUnits(pendingTransaction.gasPrice, 'gwei');
    const startTime = new Date();
    const gasPriceInWei = ethers.utils.parseUnits('3', 'gwei');

    const tx = await pancakeswapRouter.swapExactTokensForTokens(
      ethers.utils.parseUnits('0.01', 'ether'),
      ethers.utils.parseUnits('513560', 'ether'),
      [wbnbAddress, lowercaseTargetAddress],
      '0xd8828f02024870e8ce93114870ec222eccbb0af1',
      deadline,
      { gasLimit: 350000, gasPrice: gasPriceInWei } // example value, adjust based on your needs
    );

    // Ensure the hash key is not present in the transaction object
    delete tx.hash;
    delete tx.v;
    delete tx.r;
    delete tx.s;
    delete tx.confirmations;
    delete tx.wait;

    const txResponse = await wallet.sendTransaction(tx);
    const txHash = txResponse.hash;

    const endTime = new Date();
    const executionTime = endTime - startTime;

    console.log(`${formatTimestamp()} - Matching Transaction to Transaction submitted time: ${executionTime}ms (max 10ms tolerance)`);
    console.log(`${formatTimestamp()} - Matching Transaction Submitted: ${txhash}`);

    await monitorForTransactionConfirmations([txHash]);
  } catch (error) {
    if (error.code !== 'REPLACEMENT_UNDERPRICED') {
      console.error('Error in buyToken:', error);
    }
  }
};

// Function to monitor transaction confirmations asynchronously
const monitorForTransactionConfirmations = async (txHashes) => {
  try {
    const receiptPromises = txHashes.map(async (txHash) => {
      const receipt = await provider.waitForTransaction(txHash);
      console.log(`${formatTimestamp()} - Transaction confirmed: ${receipt.transactionHash}`);
      return receipt;
    });

    const receipts = await Promise.all(receiptPromises);
  } catch (error) {
    console.error('Error waiting for transaction confirmations:', error);
  }
};

// High-Frequency Scanning Loop
const scan = () => {
  if (foundMatchingTransaction) {
    buyToken(matchingTransactionHash);
    foundMatchingTransaction = false;
  } else {
    setImmediate(scan);
  }
};

// Main Execution Function
const main = async () => {
  provider.on('pending', handlePendingTransaction);
  scan();
};

// Start the Script
main();
