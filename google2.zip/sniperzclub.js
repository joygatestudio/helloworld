require('dotenv').config();
const { ethers } = require('ethers');
const fs = require('fs');

// Pre-calculate constants
const contractAddress = '0xFDDd167a7d3840f65e3497acBe53cbA487a6Cd20';
const patterns = ['0xf305d719', '0xcb9a57d2', '0xc9567bf9', '0x01339c21'];

// Load configurations and set up providers, wallets, and contracts beforehand
const config = JSON.parse(fs.readFileSync('config.json', 'utf8'));
const ERC20_ABI = JSON.parse(fs.readFileSync('./abi/erc20.json', 'utf8'));
const contractABI = JSON.parse(fs.readFileSync('./abi/swap.json', 'utf8'));
const targetAddress = config.targetAddress.toLowerCase();
const provider = new ethers.providers.WebSocketProvider(process.env.WSSNODE);
const wallet = new ethers.Wallet(process.env.PRIVATE_KEY, provider);
const sniperContract = new ethers.Contract(contractAddress, contractABI, wallet);
const path = [config.wbnbAddress, config.targetAddress];
const to = process.env.YOUR_WALLET.split(',');

// Maximum possible uint256 value: 2^256 - 1 for Pre-approval
const MAX_UINT256 = ethers.BigNumber.from('0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff');

async function preApprove() {
  const tokenContract = new ethers.Contract(config.targetAddress, ERC20_ABI, wallet);

  try {
    const approveTx = await tokenContract.approve(contractAddress, MAX_UINT256);
    const receipt = await approveTx.wait();
    console.log(`Approval completed with max amount in block ${receipt.blockNumber}`);
  } catch (error) {
    console.error('Approval error:', error);
  }
}

// Mempool function to listen to the pending transactions
async function mempool() {
  provider.on('pending', async (tx) => {
    try {
      const txInfo = await provider.getTransaction(tx);

      if (txInfo && matchPatterns(txInfo)) {
        buyToken(txInfo.gasPrice, txInfo.gasLimit);
        provider.removeAllListeners('pending');
      }
    } catch (error) {
      console.error('Error:', error);
    }
  });
}

// Match the patterns with the transaction info
function matchPatterns(txInfo) {
  const modTarget = targetAddress.replace(/^0x/, '');

  for (const pattern of patterns) {
    const regex = new RegExp('^' + pattern, 'i');
    if (regex.test(txInfo.data) && txInfo.data.includes(modTarget)) {
      return true;
    }
  }
  return false;
}

// Function to buy token
async function buyToken(gasPrice, gasLimit) {
  const deadline = Math.floor(Date.now() / 1000) + 60 * 20;
  const gasPriceInGwei = ethers.utils.formatUnits(gasPrice, 9);

  try {
    const tx = await sniperContract.sniperZclub('0', path, to, deadline, 1, 1, {
      value: ethers.utils.parseEther(config.bnbAmount),
      gasPrice: ethers.utils.parseUnits(gasPriceInGwei, 'gwei'),
      gasLimit: ethers.BigNumber.from('450000'),
    });

    console.log(`Txns hash: ${tx.hash}`);
    const receipt = await tx.wait();
    console.log(`Confirmed (block) ${receipt.blockNumber}`);
  } catch (error) {
    console.error('Error:', error);
  }
}

// Call the pre-approval function before starting the mempool listener
async function main() {
  await preApprove();
  mempool();
}

main();
