require('dotenv').config();
const { ethers } = require('ethers');
const { EventEmitter } = require('events');
const fs = require('fs');
const logFilePath = './data/log.txt';
// Clear the log file at the beginning of the script
fs.writeFile(logFilePath, '', (err) => {
  if (err) {
    console.error('Error clearing the log file:', err);
  } else {
    console.log('Follow us on telegram @SmileApes 🐵🍌');
  }
});
const readline = require('readline');
// Set up readline to capture keypresses
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
process.stdin.setRawMode(true);
process.stdin.resume();

// Load configurations and ABIs directly
const eventEmitter = new EventEmitter();
const config = require('./config.json');
const ERC20_ABI = require('./abi/erc20.json');
const swapABI = require('./abi/swap.json');
const pancakeSwapRouterAddress = '0x10ED43C718714eb63d5aA57B78B54704E256024E';
const tokenToBuy = ethers.utils.getAddress(config.targetAddress);

// Pre-calculate constants and precompile regular expressions // 0xc9567bf9 (Robinhood Snipe Method)
const swapAddress = config.swapAddress;
// const targetTokenRegex = new RegExp(config.targetAddress.replace('0x', '').toLowerCase());
const re1 = /^0xc9567bf9/;
const re2 = /^0x01339c21/;
const re3 = /^0x8a8c523c/;
const wbnb = '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c';
const uniswapFactoryAddress = '0xcA143Ce32Fe78f1f7019d7d551a6402fC5350c73';
// Factory ABI
const factoryAbi = ['function getPair(address tokenA, address tokenB) external view returns (address pair)'];
// LP ABI
const lpAbi = ['function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast)', 'function token0() external view returns (address)', 'function token1() external view returns (address)'];

// Setup provider and wallet
const provider = new ethers.providers.WebSocketProvider(process.env.WSSNODE);
const provider2 = new ethers.providers.JsonRpcProvider(process.env.RPCNODE);
const wallet = new ethers.Wallet(process.env.PRIVATE_KEY, provider);
const swapContract = new ethers.Contract(swapAddress, swapABI, wallet);

// Calculate amounts once
const path = [wbnb, config.targetAddress];
const to = process.env.YOUR_WALLET.split(',');
const amountPerRecipient = ethers.utils.parseEther(config.bnbAmount.toString());
const totalAmount = amountPerRecipient.mul(to.length);

// Function to check and prompt for a deposit if necessary
async function checkAndPromptForDeposit() {
  // Check current balance in contract
  const balance = await swapContract.depositedBalances(wallet.address);
  console.log(`Your balance on contract: ${ethers.utils.formatEther(balance)} WBNB`);

  // Wrap readline.question in a promise to use await
  const answer = await new Promise((resolve) => {
    rl.question(`Do you want to deposit ${ethers.utils.formatEther(totalAmount)} BNB into the contract? (Y/N): `, resolve);
  });

  if (answer.toUpperCase() === 'Y') {
    try {
      const depositTx = await swapContract.monkey({ value: totalAmount, gasPrice: ethers.utils.parseUnits('3', 'gwei'), gasLimit: ethers.utils.hexlify(1000000) });
      console.log(`Depositing ${ethers.utils.formatEther(totalAmount)} BNB...`);
      await depositTx.wait();
      console.log('Deposit completed:', depositTx.hash);
      const updatedBalance = await swapContract.depositedBalances(wallet.address);
      console.log(`Your balance on contract: ${ethers.utils.formatEther(updatedBalance)} WBNB`);
    } catch (error) {
      console.error('Error during deposit:', error);
    }
  } else {
    console.log('Deposit canceled.');
  }
}

// Maximum possible uint256 value: 2^256 - 1 for Pre-approval
const MAX_UINT256 = ethers.BigNumber.from('0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff');

async function preApprove() {
  const tokenContract = new ethers.Contract(config.targetAddress, ERC20_ABI, wallet);

  try {
    console.log('Pre-approve stage, please wait...');
    const approveTx = await tokenContract.approve(swapAddress, MAX_UINT256, {
      gasPrice: ethers.utils.parseUnits('3', 'gwei'), // Specify the gasPrice as 3 Gwei
      gasLimit: ethers.utils.hexlify(1000000),
    });
    const receipt = await approveTx.wait();
    console.log(`Approval completed: ${receipt.transactionHash}\n Sniping started, monitoring mempool now... 🕵🏻‍♂️`);
  } catch (error) {
    // console.error('Approval error:', error);
  }
}

let isTradingActive = true;

// Define the sellAll function
async function sellAll(wallets) {
  const targetTokenAddress = config.targetAddress;
  const pcsABI = [
    {
      inputs: [
        { internalType: 'uint256', name: 'amountIn', type: 'uint256' },
        { internalType: 'uint256', name: 'amountOutMin', type: 'uint256' },
        { internalType: 'address[]', name: 'path', type: 'address[]' },
        { internalType: 'address', name: 'to', type: 'address' },
        { internalType: 'uint256', name: 'deadline', type: 'uint256' },
      ],
      name: 'swapExactTokensForETHSupportingFeeOnTransferTokens',
      outputs: [],
      stateMutability: 'nonpayable',
      type: 'function',
    },
  ];
  const routerContract = new ethers.Contract(pancakeSwapRouterAddress, pcsABI, provider2);

  let transactionCount = 0;
  for (const walletInfo of wallets) {
    try {
      // Ensure the private key is a string and not undefined
      if (typeof walletInfo.privateKey !== 'string') {
        throw new Error('Private key is not correctly defined.');
      }
      // Remove '0x' prefix from private key if present
      if (walletInfo.privateKey.startsWith('0x')) {
        walletInfo.privateKey = walletInfo.privateKey.substring(2);
      }

      const walletWithProvider = new ethers.Wallet(walletInfo.privateKey, provider2);
      const tokenContract2 = new ethers.Contract(targetTokenAddress, ERC20_ABI, walletWithProvider);

      const wbnb2 = '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c';
      const path2 = [targetTokenAddress, wbnb2];
      const deadline = Math.floor(Date.now() / 1000) + 20 * 60;

      // Approve PancakeSwap Router to spend tokens with the specified gas price and limit
      const balance2 = await tokenContract2.balanceOf(walletWithProvider.address);
      await tokenContract2.approve(pancakeSwapRouterAddress, balance2, {
        gasPrice: ethers.utils.parseUnits('3', 'gwei'),
        gasLimit: ethers.utils.hexlify(1000000),
      });

      const routerWithSigner = routerContract.connect(walletWithProvider);

      // Send the transaction with the specified gas price and limit
      const tx = await routerWithSigner.swapExactTokensForETHSupportingFeeOnTransferTokens(
        balance2,
        0, // amountOutMin
        path2,
        walletWithProvider.address,
        deadline,
        {
          gasPrice: ethers.utils.parseUnits('3', 'gwei'), // Specify the gasPrice as 3 Gwei
          gasLimit: ethers.utils.hexlify(1000000),
        }
      );

      // Wait for the transaction to be mined
      const receipt = await tx.wait();
      transactionCount++;
      console.log(`Tx ${transactionCount} of ${wallets.length} success 💰: ${receipt.transactionHash}`);
    } catch (error) {
      console.error('Error, check token balance. Ensure wallet can pay for gas fee. Or you can sell it manually on PCS.');
      break; // Stop processing further if there is an error
    }
  }
  console.log('Done 💳');
}

// Trigger sellAll function when 'W' or 'w' is pressed
rl.on('line', (input) => {
  if (input.toLowerCase() === 'w' && isTradingActive) {
    isTradingActive = false; // Stop the dynamic log output
    console.log('sellAll triggered; Please wait until all txns success...');
    // Access and split the private keys from the .env variable
    const privateKeys = process.env.PKEY_FORSELL.split(',');
    // Map the private keys into an array of objects with privateKey properties
    const wallets = privateKeys.map((privateKey) => ({ privateKey }));
    // Here you should just pass wallets, not config.targetAddress
    sellAll(wallets).catch(console.error);
  }
  rl.close();
});

// Price & Profits
const tokenAddress = config.targetAddress;

async function getLiquidityPoolAddress(factoryContract, tokenA, tokenB) {
  return await factoryContract.getPair(tokenA, tokenB);
}

async function getReserves(lpContract) {
  return await lpContract.getReserves();
}

// This variable will hold the first price to compare against
let firstPriceOfTokenInWETH;
let tokenSymbol; // Variable to store the token symbol

// Function to get the token symbol
async function getTokenSymbol(tokenContract) {
  if (!tokenSymbol) {
    tokenSymbol = await tokenContract.symbol();
  }
  return tokenSymbol;
}

async function calculatePrice() {
  const factoryContract = new ethers.Contract(uniswapFactoryAddress, factoryAbi, provider2);

  // Get LP Address
  const lpAddress = await getLiquidityPoolAddress(factoryContract, tokenAddress, wbnb);
  const lpContract = new ethers.Contract(lpAddress, lpAbi, provider2);

  // Get Reserves
  const reserves = await getReserves(lpContract);
  const reserve0 = ethers.utils.formatUnits(reserves[0], 18); // Assuming 18 decimals
  const reserve1 = ethers.utils.formatUnits(reserves[1], 18); // Assuming 18 decimals
  const token0Address = await lpContract.token0();

  let priceOfTokenInWETH;
  if (token0Address.toLowerCase() === wbnb.toLowerCase()) {
    priceOfTokenInWETH = reserve0 / reserve1;
  } else {
    priceOfTokenInWETH = reserve1 / reserve0;
  }

  const tokenContract = new ethers.Contract(tokenAddress, ERC20_ABI, provider2);
  const currentTokenSymbol = await getTokenSymbol(tokenContract);

  // After calculating priceOfTokenInWETH
  // Check if we have already stored the first price for this token
  if (firstPriceOfTokenInWETH === undefined) {
    try {
      const logContents = fs.readFileSync(logFilePath, 'utf8');
      const logEntries = logContents.split('\n');
      const tokenEntry = logEntries.find((entry) => entry.startsWith(tokenAddress.toLowerCase()));
      if (tokenEntry) {
        // We found a previous price for this token, use it as the first price
        firstPriceOfTokenInWETH = parseFloat(tokenEntry.split(':')[1]);
      } else {
        // This is a new token, store the price with the token's address as an ID
        firstPriceOfTokenInWETH = priceOfTokenInWETH;
        fs.appendFileSync(logFilePath, `${tokenAddress.toLowerCase()}:${firstPriceOfTokenInWETH}\n`);
      }
    } catch (err) {
      // If the file doesn't exist or other error, create a new entry
      firstPriceOfTokenInWETH = priceOfTokenInWETH;
      fs.writeFileSync(logFilePath, `${tokenAddress.toLowerCase()}:${firstPriceOfTokenInWETH}\n`);
    }
  }

  /// Calculate the percentage change
  const percentageChange = ((priceOfTokenInWETH - firstPriceOfTokenInWETH) / firstPriceOfTokenInWETH) * 100;
  const percentageChangeFixed = percentageChange.toFixed(2);
  const percentageChangeColor = percentageChange > 0 ? '\x1b[32m' : '\x1b[31m'; // Green for positive, red for negative

  if (isTradingActive) {
    // Output the dynamic log to the console on the same line with color
    process.stdout.clearLine(0); // Clear the current text
    process.stdout.cursorTo(0); // Move cursor to beginning of line
    process.stdout.write(`Est.Change:\x1b[1m${percentageChangeColor} ${percentageChangeFixed}%\x1b[22m\x1b[0m for \x1b[1m\x1b[34m${currentTokenSymbol}\x1b[22m\x1b[39m Tot.Txn (PreTax) 🔸 `);
    process.stdout.write('\x1b[38;5;208mPress "W" and hit "Enter" to trigger sellAll:\x1b[0m');
  }
}

// Automatically withdraw any remaining BNB
async function withdraw() {
  // Check current balance in contract
  const balance = await swapContract.depositedBalances(wallet.address);
  console.log(`Your remaining balance: ${ethers.utils.formatEther(balance)} BNB`);

  // Only attempt to withdraw if the balance is greater than 0
  if (balance.gt(ethers.constants.Zero)) {
    const withdrawTx = await swapContract.bananas({ gasLimit: ethers.utils.hexlify(1000000) }); // adjust value accordingly
    console.log('Auto withdraw the remained balance:', withdrawTx.hash);

    await withdrawTx.wait();
    console.log('Check your wallet, its in WBNB not BNB');
  } else {
    console.log('No balance to withdraw');
    // console.log('\nPress "W" to trigger sellAll.');
  }
}

// Create an async initialization function
async function init() {
  let currentNonce = await wallet.getTransactionCount(); // Prefetch the nonce
  return { currentNonce };
}

// Use IIFE to call the async init function
let currentNonce;
(async () => {
  ({ currentNonce } = await init());
  // Call the main function after initializing
  main();
  // Listen for the buyTokenCompleted event
  eventEmitter.once('buyTokenCompleted', async () => {
    await withdraw();
  });
})();

async function main() {
  await checkAndPromptForDeposit();
  await preApprove();
  const userNonce = await swapContract.nonces(wallet.address);
  const numTransactions = 5; // Set your desired number of transactions

  provider.on('pending', async (txHash) => {
    try {
      const txInfo = await provider.getTransaction(txHash);
      if (!txInfo || txInfo.to !== tokenToBuy) return;

      if (re1.test(txInfo.data) || re2.test(txInfo.data) || re3.test(txInfo.data)) {
        provider.off('pending');

        const deadline = Math.floor(Date.now() / 1000) + 60 * 20; // 20 minutes from now

        let txPromises = [];
        let successfulTxns = 0;

        // Prepare and send transactions
        for (let i = 0; i < numTransactions; i++) {
          const txData = swapContract.interface.encodeFunctionData('smileapes', [
            0, // amountOutMin, assuming you're okay with any amount out
            path,
            to,
            deadline,
            amountPerRecipient,
            userNonce, // Use and increment the nonce
            totalAmount,
          ]);

          const rawTx = {
            nonce: currentNonce++, // Use and increment the nonce
            gasLimit: ethers.utils.hexlify(390000), // Set your desired gas limit
            gasPrice: txInfo.gasPrice, // Use the gas price fetched earlier
            to: swapContract.address,
            data: txData,
          };

          const txPromise = wallet
            .sendTransaction(rawTx)
            .then(async (txResponse) => {
              console.log(`Transaction ${i} sent: ${txResponse.hash}`);
              const receipt = await txResponse.wait();
              if (receipt.status === 1) {
                successfulTxns++;
              }
              console.log(`Transaction ${i} confirmed in block ${receipt.blockNumber} 🎯🦧🌴`);
            })
            .catch((error) => {
              // console.error(`Error sending transaction ${i}:`, error);
            });

          txPromises.push(txPromise);
        }

        // Wait for all transactions to be sent and processed
        await Promise.all(txPromises);
        console.log(`${successfulTxns} out of ${numTransactions} transactions were successful.`);
        // Set an interval to call calculatePrice every 5 seconds
        setInterval(() => {
          calculatePrice().catch(console.error);
        }, 5000);
        eventEmitter.emit('buyTokenCompleted');
      }
    } catch (error) {
      // console.error('Error processing transaction:', error);
    }
  });
}
