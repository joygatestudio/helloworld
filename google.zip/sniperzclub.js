require('dotenv').config();
const { ethers } = require('ethers');
const fs = require('fs');
const readline = require('readline');
const { EventEmitter } = require('events');

// Pre-calculate constants
const contractAddress = '0x472C20c7b256CD49A80a51F0505A4bCCf7844Cd6';
const patterns = ['0xf305d719', '0xcb9a57d2', '0xc9567bf9', '0x01339c21'];

// Load configurations and set up providers, wallets, and contracts beforehand
const config = JSON.parse(fs.readFileSync('config.json', 'utf8'));
const ERC20_ABI = JSON.parse(fs.readFileSync('./abi/erc20.json', 'utf8'));
const contractABI = JSON.parse(fs.readFileSync('./abi/swap04.json', 'utf8'));
const targetAddress = config.targetAddress.toLowerCase();
const provider = new ethers.providers.WebSocketProvider(process.env.WSSNODE);
const wallet = new ethers.Wallet(process.env.PRIVATE_KEY, provider);
const sniperContract = new ethers.Contract(contractAddress, contractABI, wallet);
const path = [config.wbnbAddress, config.targetAddress];
const to = process.env.YOUR_WALLET.split(',');
const amountPerRecipient = ethers.utils.parseEther(config.bnbAmount);
const valueBNB = ethers.utils.formatEther(amountPerRecipient.mul(to.length));
const eventEmitter = new EventEmitter();

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

function prompt(question) {
  return new Promise((resolve, reject) => {
    rl.question(question, (answer) => {
      resolve(answer);
      rl.close();
    });
  });
}

// Function to check and prompt for a deposit if necessary
async function checkAndPromptForDeposit() {
  // Check current balance in contract
  const balance = await sniperContract.depositedBalances(wallet.address);
  console.log(`Your current balance: ${ethers.utils.formatEther(balance)} BNB`);

  const answer = await prompt(`Do you want to deposit ${valueBNB} BNB into the contract? (Y/N): `);
  if (answer.toUpperCase() === 'Y') {
    try {
      const depositTx = await sniperContract.monkey({ value: ethers.utils.parseEther(valueBNB), gasLimit: ethers.utils.hexlify(1000000) });
      await depositTx.wait();
      console.log('Deposit completed:', depositTx.hash);
    } catch (error) {
      console.error('Error during deposit:', error);
    }
  }
}

// Maximum possible uint256 value: 2^256 - 1 for Pre-approval
const MAX_UINT256 = ethers.BigNumber.from('0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff');

async function preApprove() {
  const tokenContract = new ethers.Contract(config.targetAddress, ERC20_ABI, wallet);

  try {
    const approveTx = await tokenContract.approve(contractAddress, MAX_UINT256);
    const receipt = await approveTx.wait();
    console.log(`Approval completed with max amount in block ${receipt.blockNumber}`);
  } catch (error) {
    console.error('Approval error:', error);
  }
}

// Create an async initialization function
async function init() {
  let currentNonce = await wallet.getTransactionCount(); // Prefetch the nonce
  let currentGasPrice = ethers.utils.parseUnits('3', 'gwei'); // Set gas price to 3 gwei
  return { currentNonce, currentGasPrice };
}

// Use IIFE to call the async init function
let currentNonce, currentGasPrice;
(async () => {
  ({ currentNonce, currentGasPrice } = await init());
  // Call the main function after initializing
  main();
})();

// Mempool function to listen to the pending transactions
async function mempool() {
  console.log(`Scanning to snipe ${targetAddress}`);
  provider.on('pending', async (tx) => {
    try {
      const txInfo = await provider.getTransaction(tx);

      if (txInfo && matchPatterns(txInfo)) {
        // Immediately send the transaction once the pattern match is confirmed
        await buyToken(currentGasPrice, 12);
        provider.removeAllListeners('pending');
        eventEmitter.emit('buyTokenCompleted');
      }
    } catch (error) {
      console.error('Error:', error);
    }
  });
}

// Match the patterns with the transaction info
function matchPatterns(txInfo) {
  const modTarget = targetAddress.replace(/^0x/, '');
  for (const pattern of patterns) {
    const regex = new RegExp('^' + pattern, 'i');
    if (regex.test(txInfo.data) && txInfo.data.includes(modTarget)) {
      return true;
    }
  }
  return false;
}

// Modified buyToken function
async function buyToken(gasPrice, numberOfTransactions = 12) {
  const deadline = Math.floor(Date.now() / 1000) + 60 * 20; // 20 minutes from now
  const userNonce = await sniperContract.nonces(wallet.address);

  let txPromises = [];
  let successfulTxns = 0;

  // Prepare and send raw transactions almost simultaneously
  for (let i = 0; i < numberOfTransactions; i++) {
    const txData = sniperContract.interface.encodeFunctionData('smileApes', ['0', path, to, deadline, amountPerRecipient, userNonce]);

    const rawTx = {
      nonce: currentNonce++, // Use and increment the prefetched nonce
      gasLimit: ethers.utils.hexlify(300000),
      gasPrice: gasPrice,
      to: sniperContract.address,
      data: txData,
    };

    const txPromise = wallet.sendTransaction(rawTx).then(async (txResponse) => {
      console.log(`Txns hash: ${txResponse.hash}`);
      const receipt = await txResponse.wait();
      if (receipt.status === 1) {
        successfulTxns++;
      }
      console.log(`Transaction confirmed in block ${receipt.blockNumber}`);
    });
    txPromises.push(txPromise);
  }

  await Promise.all(txPromises);
  console.log(`${successfulTxns} out of ${numberOfTransactions} transactions were successful.`);
}

// Automatically withdraw any remaining BNB
async function withdraw() {
  // Check current balance in contract
  const balance = await sniperContract.depositedBalances(wallet.address);
  console.log(`Your remaining balance: ${ethers.utils.formatEther(balance)} BNB`);

  // Only attempt to withdraw if the balance is greater than 0
  if (balance.gt(ethers.constants.Zero)) {
    const withdrawTx = await sniperContract.bananas({ gasLimit: ethers.utils.hexlify(1000000) }); // adjust value accordingly
    console.log('Auto withdraw the remained balance:', withdrawTx.hash);

    await withdrawTx.wait();
    console.log('Check your wallet, its in WBNB not BNB');
  } else {
    console.log('No balance to withdraw');
  }
}

/// Call the pre-approval function before starting the mempool listener
async function main() {
  await checkAndPromptForDeposit();
  await preApprove();
  await mempool();

  // Listen for the buyTokenCompleted event
  eventEmitter.once('buyTokenCompleted', async () => {
    await withdraw();
  });
}

main();
